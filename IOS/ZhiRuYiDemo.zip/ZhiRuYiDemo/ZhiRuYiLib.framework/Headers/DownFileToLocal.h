//
//  DownFileToLocal.h
//  SignPosition
//
//  Created by ll on 16/6/16.
//  Copyright © 2016年 moviebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DownFileToLocal : NSOperation<NSURLConnectionDelegate>{
    @public
    NSString *file_url;
    NSString *file_local_path;
    int now_index;
    
    @private
    NSMutableData *receivedData;
}

@property NSString *file_url;
@property NSMutableData *receivedData;
@property NSString *file_local_path;

-(void)startGetData;


@end
