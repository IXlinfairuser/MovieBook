//
//  MoviebookZoneData.h
//  playtest
//
//  Created by ll on 2017/1/13.
//  Copyright © 2017年 moviebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MoviebookZoneData : NSObject{
    NSString *exposure_time;
    NSString *second;
    NSString *x;
    NSString *y;
    NSString *width;
    NSString *height;
}

@property(nonatomic, retain) NSString *exposure_time;
@property(nonatomic, retain) NSString *second;
@property(nonatomic, retain) NSString *x;
@property(nonatomic, retain) NSString *y;
@property(nonatomic, retain) NSString *width;
@property(nonatomic, retain) NSString *height;


@end
