//
//  MoviebookFloatLayerData.h
//  playtest
//
//  Created by ll on 16/1/30.
//  Copyright © 2016年 moviebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MoviebookFloatLayerData : NSObject{
    NSString *attache_text;
    NSString *attache_url;
    NSString *click_url;
}

@property(nonatomic, retain) NSString *attache_text;
@property(nonatomic, retain) NSString *attache_url;
@property(nonatomic, retain) NSString *click_url;


@end
