//
//  MoviebookVV.h
//  playtest
//
//  Created by ll on 16/1/29.
//  Copyright © 2016年 moviebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <MediaPlayer/MPMoviePlayerController.h>
#import <AVFoundation/AVFoundation.h>
#import "MoviebookDataJson.h"
#import "MoviebookUtil.h"
#import "MoviebookFloatLayerData.h"
#import "MoviebookZoneData.h"

#define zhiruyi_have_decoder 1   // 0  not have , 1 have

#if zhiruyi_have_decoder==1
#import <IJKMediaFramework/MediaPlayer.h>
#endif

static NSTimer *get_time;
static Boolean is_ad_playing;

static int player_left;
static int player_top;
static int player_width;
static int player_height;

static AVAsset *movieAsset_ad;
static AVPlayerItem *playerItem_ad;
static AVPlayer *player_ad;
static AVPlayerLayer *playerLayer_ad;
static CGSize size_ad;
static Boolean is_playing;
static Boolean is_playing_f;
static Boolean is_playing_m;
static Boolean is_ad_init_over;

static MoviebookDataJson *now_play_ad_data;

static NSMutableData *receivedData;

static float correct_start_time;    //start time repair
static float correct_end_time;      //end time repair

static Boolean is_click_zone_useable;   //zone is useable by time
static MoviebookZoneData *now_play_zone_data;

#if zhiruyi_have_decoder==1
static MediaPlayer *ijk_player;
#endif

@interface MoviebookVV : NSObject<NSURLConnectionDelegate>{

}

+(void)synchronizeTime:(float) time withPlayerView:(UIView *) view;
+(void)initAdPathAndPlay:(NSString *) path;
+(void)initADFrameLeft:(int) left withTop:(int) top withWidth:(int) width withHeight:(int) height;
+(void)resizeADFrameLeft:(int) left withTop:(int) top withWidth:(int) width withHeight:(int) height;
+(void)playAD;
+(void)pauseAD;
+(void)closeAdPlayer;

+(void)getHttpData:(NSString *)mid withcpid:(int) cpid withra:(NSString*) ra;
+(void)downloadFile;
+(void)setJsonData:(NSString *) jsonString;

+(Boolean)touchVVEvent:(int) x withY:(int) y ;
+(Boolean)touchesVVBegan:(NSSet *)touches withEvent:(UIEvent *)event withView:(UIView *)view;
+(Boolean)touchesVVMoved:(NSSet *)touches withEvent:(UIEvent *)event withView:(UIView *)view;
+(Boolean)touchesVVEnded:(NSSet *)touches withEvent:(UIEvent *)event withView:(UIView *)view;
+(NSString *)getJumpWapURL;

@end
