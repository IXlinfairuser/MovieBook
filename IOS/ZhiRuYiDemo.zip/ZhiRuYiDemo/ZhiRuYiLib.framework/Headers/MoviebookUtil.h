//
//  MoviebookUtil.h
//  DownAndPlay
//
//  Created by ll on 15/6/25.
//  Copyright (c) 2015年 moviebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MoviebookDataJson.h"

//#define AD_API_HEAD @"http://api.zhiruyi.com"
#define AD_API_HEAD @"http://testapi.zhiruyi.cn"
//#define AD_API_HEAD @"http://demoapi.zhiruyi.cn"

static NSMutableArray *ad_data;
static NSString *folder_name;
static NSString *http_url;
static NSString *prefsFilePath;
static NSMutableDictionary *prefers;

static NSMutableData *receivedData;

@interface MoviebookUtil : NSObject{
    
}

+(NSMutableArray *)getADData;
+(void)clearADData;
+(void)addADData:(MoviebookDataJson *)now_data;
+(void)setADData:(int)index
     AndIsDownOver:(NSString *)is_down_over
     AndFilePath:(NSString *)file_path;
+(NSString *)getHttpUrl:(NSString *)mid
                  AndCpid:(int)cpid
                  AndBit:(NSString *)bit;
//+(void)downloadFile;
+(void)playCallback:(NSString *)url;

+(void)initN2;
+(NSString *)getF;
+(void)creatMovieBookFolder;
+(void)releaseMovieBookFolder;
+(int)getDeviceType;

@end
