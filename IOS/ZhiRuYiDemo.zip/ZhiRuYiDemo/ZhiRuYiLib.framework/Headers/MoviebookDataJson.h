//
//  MoviebookDataJson.h
//  DownAndPlay
//
//  Created by ll on 15/6/25.
//  Copyright (c) 2015年 moviebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MoviebookDataJson : NSObject{
    NSString *adid;
    NSString *start;
    NSString *second;
    NSString *url;
    NSString *left_coordinate;
    NSString *right_coordinate;
    NSString *pv;
    NSString *click;
    
    NSString *is_down_over;  //0 is downloading   1 download over
    NSString *file_path;
    
    NSString *product_id;
    NSString *click_url;
    NSString *times;
    NSString *x;
    NSString *y;
    NSString *width;
    NSString *height;
    NSString *mouse_over_icon;
    NSString *click_type;
    NSMutableArray *floatinglayer;
    
    NSMutableArray *zone;
    
}

@property(nonatomic, retain) NSString *adid;
@property(nonatomic, retain) NSString *start;
@property(nonatomic, retain) NSString *second;
@property(nonatomic, retain) NSString *url;
@property(nonatomic, retain) NSString *left_coordinate;
@property(nonatomic, retain) NSString *right_coordinate;
@property(nonatomic, retain) NSString *pv;
@property(nonatomic, retain) NSString *click;

@property(nonatomic, retain) NSString *is_down_over;
@property(nonatomic, retain) NSString *file_path;

@property(nonatomic, retain) NSString *product_id;
@property(nonatomic, retain) NSString *click_url;
@property(nonatomic, retain) NSString *times;
@property(nonatomic, retain) NSString *x;
@property(nonatomic, retain) NSString *y;
@property(nonatomic, retain) NSString *width;
@property(nonatomic, retain) NSString *height;
@property(nonatomic, retain) NSString *mouse_over_icon;
@property(nonatomic, retain) NSString *click_type;
@property(nonatomic, retain) NSMutableArray *floatinglayer;

@property(nonatomic, retain) NSMutableArray *zone;

@end
