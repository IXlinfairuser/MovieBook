//
//  UserSession.h
//  moviebooknew
//
//  Created by ll on 16-7-7.
//  Copyright (c) 2016年 moviebook. All rights reserved.
//

#import <Foundation/Foundation.h>

#define PREF_DEVICE_ID		@"device_id"

@interface UserSession : NSObject{
    NSString *device_id;
    NSString *prefsFilePath;
    NSMutableDictionary *prefers;
}

@property(nonatomic, copy) NSString *uid;
@property(nonatomic, copy) NSString *device_id;

+(UserSession*)getInstance;
-(void)initPrefsFilePath;

-(NSString *)getDeviceID;
@end
