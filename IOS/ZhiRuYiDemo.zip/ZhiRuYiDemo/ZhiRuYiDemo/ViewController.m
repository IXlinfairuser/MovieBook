//
//  ViewController.m
//  ZhiRuYiDemo
//
//  Created by ll on 2017/2/27.
//  Copyright © 2017年 ll. All rights reserved.
//

#import "ViewController.h"
#import <ZhiRuYiLib/MoviebookVV.h>


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIButton *_doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _doneButton.frame = CGRectMake(([[UIScreen mainScreen] bounds].size.width-120)/2, ([[UIScreen mainScreen] bounds].size.height-50)/2, 120, 50);
    _doneButton.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:255.0 alpha:0.5];
    [_doneButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_doneButton setTitle:NSLocalizedString(@"start", nil) forState:UIControlStateNormal];
    _doneButton.titleLabel.font = [UIFont systemFontOfSize:45];
    _doneButton.showsTouchWhenHighlighted = YES;
    [_doneButton addTarget:self action:@selector(doneDidTouch:)
          forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_doneButton];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) doneDidTouch: (id) sender
{
    [self playVideo];
    
    [MoviebookVV getHttpData:@"woshitest" withcpid:9 withra:@"210"];   //zhiruyi   注意文件格式需要为mp4,flv,zrym,zryf,其他格式将不会展示
    NSTimer *get_time = [NSTimer scheduledTimerWithTimeInterval:0.020 target:self selector:@selector(getNowPlayTime:) userInfo:nil repeats:YES];
    
}

-(void)getNowPlayTime:(id) object
{
    float now_playing_time=movie_Player.currentPlaybackTime;   //底层播放器现在播放的时间
    [MoviebookVV synchronizeTime:now_playing_time withPlayerView:self.view];
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    Boolean result=[MoviebookVV touchesVVBegan:touches withEvent:event withView:self.view];
}

-(void)playVideo
{
    movie_Player = [[MPMoviePlayerController alloc]initWithContentURL:[NSURL URLWithString:@"http://218.241.154.138/wscnz210sd.mp4"]];  //http://218.241.154.138/xiaoshidai.mp4     http://172.16.0.66/xiaoshidai.mp4    http://218.241.154.138/wscnz730lg.mp4    http://218.241.154.179/htdocs/jiemeixiongdi3_440000.mp4
    //chaonengluzhandui.mp4   超能陆战队    heyishengxiaomo.mp4  何以笙箫默   xiaoshidai.mp4   小时代   legend.mp4
    //wscnz730lg.mp4  wscnz440hd.mp4   wscnz210sd.mp4     //jiemeixiongdi3_260000   jiemeixiongdi3_440000
    movie_Player.view.frame = CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
    [self.view addSubview:movie_Player.view];
    
    NSNotificationCenter *notification=[NSNotificationCenter defaultCenter];
    [notification addObserver:self selector:@selector(movieLoadStateChange:) name:MPMoviePlayerReadyForDisplayDidChangeNotification object:movie_Player];
    //    [movie_Player setScalingMode:MPMovieScalingModeAspectFill];  //设置全屏播放
    [movie_Player play];
}

-(void)movieLoadStateChange:(NSNotification *)notification
{
    //    NSTimeInterval start=350;  //start from 350 second
    //    [movie_Player setCurrentPlaybackTime:start];
    //    [movie_Player pause];
    
}



@end
