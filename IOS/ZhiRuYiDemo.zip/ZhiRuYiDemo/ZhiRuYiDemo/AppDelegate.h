//
//  AppDelegate.h
//  ZhiRuYiDemo
//
//  Created by ll on 2017/2/27.
//  Copyright © 2017年 ll. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

