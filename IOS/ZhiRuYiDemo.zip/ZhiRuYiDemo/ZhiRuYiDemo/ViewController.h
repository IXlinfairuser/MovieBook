//
//  ViewController.h
//  ZhiRuYiDemo
//
//  Created by ll on 2017/2/27.
//  Copyright © 2017年 ll. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MPMoviePlayerController.h>

@interface ViewController : UIViewController{
    MPMoviePlayerController *movie_Player;
}


@end

