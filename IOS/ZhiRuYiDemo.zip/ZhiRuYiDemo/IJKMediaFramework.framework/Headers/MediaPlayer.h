//
//  MediaPlayer.h
//  MoviePlayerTest
//
//  Created by ll on 2016/10/19.
//  Copyright © 2016年 sdafsafsaf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//#import <IJKMediaFramework/IJKMediaFramework.h>
#import "IJKMediaPlayback.h"

//static NSURL *url;
//static id<IJKMediaPlayback> player;

@interface MediaPlayer : NSObject

@property(atomic,strong) NSURL *url;
@property(atomic, retain) id<IJKMediaPlayback> player;
@property(atomic) Boolean is_auto_replay;

-(void)initPlayerView:(UIView *) view andURL:(NSString *) url;
-(void)closePlayer;
-(void)pause;
-(void)play;
-(void)installMovieNotificationObservers;
-(void)removeMovieNotificationObservers;
-(void)seek;
-(int)getWidth;
-(int)getHight;
-(void)resizePlayerFrameX:(int) x andY:(int) y andWidth:(int) width andHight:(int) hight;

@end
